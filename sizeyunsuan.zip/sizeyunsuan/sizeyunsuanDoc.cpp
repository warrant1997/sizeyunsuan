// sizeyunsuanDoc.cpp : implementation of the CSizeyunsuanDoc class
//

#include "stdafx.h"
#include "sizeyunsuan.h"

#include "sizeyunsuanDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSizeyunsuanDoc

IMPLEMENT_DYNCREATE(CSizeyunsuanDoc, CDocument)

BEGIN_MESSAGE_MAP(CSizeyunsuanDoc, CDocument)
	//{{AFX_MSG_MAP(CSizeyunsuanDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSizeyunsuanDoc construction/destruction

CSizeyunsuanDoc::CSizeyunsuanDoc()
{
	// TODO: add one-time construction code here

}

CSizeyunsuanDoc::~CSizeyunsuanDoc()
{
}

BOOL CSizeyunsuanDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}





/////////////////////////////////////////////////////////////////////////////
// CSizeyunsuanDoc serialization

void CSizeyunsuanDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CSizeyunsuanDoc diagnostics

#ifdef _DEBUG
void CSizeyunsuanDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CSizeyunsuanDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSizeyunsuanDoc commands

BOOL CSizeyunsuanDoc::OnSaveDocument(LPCTSTR lpszPathName) 
{
	// TODO: Add your specialized code here and/or call the base class


	return CDocument::OnSaveDocument(lpszPathName);
}

// Problem.cpp : implementation file
//
#include "stdafx.h"
#include "sizeyunsuan.h"
#include "Problem.h"
#include "sizeyunsuanView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Problem dialog
//extern int pron,prin,black,sele;

Problem::Problem(CWnd* pParent /*=NULL*/)
	: CDialog(Problem::IDD, pParent)
{
	//{{AFX_DATA_INIT(Problem)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void Problem::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Problem)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(Problem, CDialog)
	//{{AFX_MSG_MAP(Problem)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Problem message handlers

void Problem::OnOK()
{   
	//int pron,prin,black,select;
	// TODO: Add extra validation here
	pron=GetDlgItemInt(IDC_EDIT1);
    prin=GetDlgItemInt(IDC_EDIT2);
	black=GetDlgItemInt(IDC_EDIT3);
	int RadioState=((CButton *)GetDlgItem(IDC_RADIO1))->GetCheck();//����1��ʾѡ�ϣ�0��ʾûѡ��
    if(RadioState==1)
	{  sele=1;
	}else{
		sele=0;
	}
	::PostMessage(NULL, WM_GETMESSAGE, pron, 0);
 
	CDialog::OnOK();
}

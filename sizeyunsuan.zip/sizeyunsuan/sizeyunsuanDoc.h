// sizeyunsuanDoc.h : interface of the CSizeyunsuanDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SIZEYUNSUANDOC_H__CB2A50B6_E838_4D89_B0A2_F59B2C849802__INCLUDED_)
#define AFX_SIZEYUNSUANDOC_H__CB2A50B6_E838_4D89_B0A2_F59B2C849802__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CSizeyunsuanDoc : public CDocument
{
protected: // create from serialization only
	CSizeyunsuanDoc();
	DECLARE_DYNCREATE(CSizeyunsuanDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSizeyunsuanDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual BOOL OnSaveDocument(LPCTSTR lpszPathName);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CSizeyunsuanDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CSizeyunsuanDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIZEYUNSUANDOC_H__CB2A50B6_E838_4D89_B0A2_F59B2C849802__INCLUDED_)

// sizeyunsuanView.cpp : implementation of the CSizeyunsuanView class
//

#include "stdafx.h"
#include "sizeyunsuanView.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//int pron,prin,black,sele;

/////////////////////////////////////////////////////////////////////////////
// CSizeyunsuanView

IMPLEMENT_DYNCREATE(CSizeyunsuanView, CView)

BEGIN_MESSAGE_MAP(CSizeyunsuanView, CView)
	//{{AFX_MSG_MAP(CSizeyunsuanView)
	ON_COMMAND(ID_CProblem, OnCProblem)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)

	// !!!! ����Ϣmap�У���������Ϣ��������
	ON_MESSAGE(WM_GETMESSAGE, OnDraw)

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSizeyunsuanView construction/destruction
CSizeyunsuanView::CSizeyunsuanView()
{
	// TODO: add construction code here

}

CSizeyunsuanView::~CSizeyunsuanView()
{
}

BOOL CSizeyunsuanView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CSizeyunsuanView drawing

void CSizeyunsuanView::OnDraw(CDC* pDC)
{
	CSizeyunsuanDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
	CFont font;
	font.CreatePointFont(10,"�����п�");
	
	//int edit1,edit2,edit3,sele;
    //OnOK(edit1,sele,edit2,edit3); //number the dialog obtained
    int count=0;
	int x=0,y=0;
	Problem p;

	for(int i=0;i<p.pron;i++)
	{   
		srand(i);
		float num1=rand()%20;
        float num2=rand()%20;
		float num3=rand()%20;
		int op1=rand()%4;
        int op2=rand()%4;
		CString opt1,opt2;
		CString str1;
		//str1.Format(_T("%d",num1));
        str1.Format("%d",num1);
		CString str2;
		str2.Format("%d",num2);
		CString str3;
		str3.Format("%d",num3);
		CString countnum,ans;

		int answer=0;

		if(op1==0)
		{
			if(op2==0) 
			{	opt1="+";
			    opt2="+";
				answer=num1+num2+num3;
			}
			if(op2==1)
			{   opt1="+";
			    opt2="-";
				answer=num1+num2-num3;
            }
			if(op2==2)
			{	opt1="+";
			    opt2="*";
				answer=num1+num2*num3;
			}
			if(op2==3)
			{	opt1="+";
			    opt2="/";
				answer=num1+num2/num3;
			}
		}
        if(op1==1)
		{
			if(op2==0) 
			{	opt1="-";
			    opt2="+";
				answer=num1-num2+num3;
			}
			if(op2==1)
			{   opt1="-";
			    opt2="-";
				answer=num1-num2-num3;
			}
            if(op2==2)
            {    opt1="-";
			    opt2="*";
				answer=num1-num2*num3;
			}
			if(op2==3)
			{   opt1="-";
			    opt2="/";
				answer=num1-num2/num3;
			}
		}
		if(op1==2)
		{
			if(op2==0) 
			{	opt1="*";
			    opt2="+";
				answer=num1*num2*num3;
			}
			if(op2==1)
            {   opt1="*";
			    opt2="-";
				answer=num1*num2-num3;
			}
            if(op2==2)
            {   opt1="*";
			    opt2="*";
				answer=num1*num2*num3;
			}
			if(op2==3)
			{   opt1="*";
			    opt2="/";
				answer=num1*num2/num3;
			}
		}
		if(op1==3)
		{
			if(op2==0) 
			{	opt1="/";
			    opt2="+";
				answer=num1/num2+num3;
			}
			if(op2==1)
            {   opt1="/";
			    opt2="-";
				answer=num1/num2-num3;
			}
            if(op2==2)
            {   opt1="/";
			    opt2="*";
				answer=num1/num2*num3;
			}
			if(op2==3)
			{   opt1="/";
			    opt2="/";
				answer=num1/num2/num3;
			}
		}
		if((count>0)&&(count%p.prin==0))
		{   x=0;
			y+=30;
		}
		if(p.black>0)
		{  y=p.black*30;
		}
		count++;
		countnum.Format("%d",count);
		ans.Format("%d",answer);
		pDC->TextOut(x,y,countnum);
        pDC->TextOut(x+15,y,":");
     	pDC->TextOut(x+30,y,str1);
		pDC->TextOut(x+45,y,opt1);
        pDC->TextOut(x+60,y,str2);
		pDC->TextOut(x+75,y,opt2);
		pDC->TextOut(x+90,y,str3);
        pDC->TextOut(x+110,y,"=");
		if(p.sele==1)
		{  pDC->TextOut(x+130,y,ans);
		}
		x+=200;	
	}
}

/////////////////////////////////////////////////////////////////////////////
// CSizeyunsuanView printing

BOOL CSizeyunsuanView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CSizeyunsuanView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CSizeyunsuanView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CSizeyunsuanView diagnostics

#ifdef _DEBUG
void CSizeyunsuanView::AssertValid() const
{
	CView::AssertValid();
}

void CSizeyunsuanView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CSizeyunsuanDoc* CSizeyunsuanView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSizeyunsuanDoc)));
	return (CSizeyunsuanDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSizeyunsuanView message handlers

void CSizeyunsuanView::OnCProblem() 
{
	// TODO: Add your command handler code here
	Problem dlg;  //response to Problem menu
	dlg.DoModal();
}
